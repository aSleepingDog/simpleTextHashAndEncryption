import subprocess
import win
from tkinter import messagebox

if __name__ == '__main__':
    try:
        subprocess.run("bin\\PINEngine.exe",capture_output=False)
        win = win.Window("加密程序", "bin\\PINEngine.exe")
    except FileNotFoundError:
        messagebox.showerror("错误","no PINEngine.exe\n没有PINEngine.exe程序")
