import tkinter
from idlelib.undo import Command
from tempfile import tempdir
from tkinter import messagebox
from tkinter.ttk import Combobox
from tkinter import scrolledtext
import subprocess

class Window:
    __Window =tkinter.Tk()
    __font="SourceHanSerifCN-Medium.otf"
    __PINEngine=None

    __plainFrame=None
    __plainTextLabel=None
    __plainText=None
    __plainCodingLabel=None
    __plainCoding=None

    __encryptionFrame=None
    __encryptionLabel=None
    __encryptionPswLabel=None
    __encryptionPswEntry=None
    __encryptionPswCodingLabel=None
    __encryptionPswCoding=None
    __encryptionFunctionLabel=None
    __encryptionFunction=None
    __encryptionModeLabel=None
    __encryptionMode=None
    __encryptionFillingLabel=None
    __encryptionFilling=None

    __hashFrame=None
    __hashFunctionLabel=None
    __hashFunction=None

    __MethodFrame=None
    __MethodLabel=None
    __MethodString=tkinter.StringVar()
    __MethodR1=None
    __MethodR2=None
    __MethodR3=None

    __resultFrame=None
    __resultTextLabel=None
    __resultText=None
    __resultCodingLabel=None
    __resultCoding=None
    __resultBase64Char1=None
    __resultBase64Char2=None
    __resultBase64Char3=None
    __resultBase64Entry1=None
    __resultBase64Entry2=None
    __resultBase64Entry3=None
    __resultSpendLabel=None
    __resultSpendString=tkinter.StringVar()
    __resultSpend=None

    __startButton=None

    def __init__(self,title,PINEngine):
        self.__Window.title(title)
        self.__Window.geometry("725x555")
        self.__PINEngine=PINEngine

        self.__plainFrame=tkinter.Frame(self.__Window)
        self.__plainFrame.grid(column=0, row=0, columnspan=3)
        self.__plainTextLabel=tkinter.Label(self.__plainFrame,text="输入",font=(self.__font,12))
        self.__plainTextLabel.grid(column=0, row=0)
        self.__plainText=scrolledtext.ScrolledText(self.__plainFrame,width=100,height=10,font=("等线",10))
        self.__plainText.grid(column=0, row=1,columnspan=20)
        self.__plainCodingLabel=tkinter.Label(self.__plainFrame,text="编码类型")
        self.__plainCodingLabel.grid(column=0, row=2,sticky=tkinter.E)
        self.__plainCoding=Combobox(self.__plainFrame,width=7)
        self.__plainCoding["values"]=["utf-8","Base64","16Hex"]
        self.__plainCoding.current(0)
        self.__plainCoding.grid(column=1, row=2,sticky=tkinter.W)

        self.__encryptionFrame=tkinter.Frame(self.__Window)
        self.__encryptionFrame.grid(column=0, row=1,columnspan=2)
        self.__encryptionLabel=tkinter.Label(self.__encryptionFrame,text="加密/解密选项",font=(self.__font,12))
        self.__encryptionLabel.grid(column=0, row=0,columnspan=4)
        self.__encryptionPswLabel=tkinter.Label(self.__encryptionFrame,text="密码")
        self.__encryptionPswLabel.grid(column=0, row=1,sticky=tkinter.E)
        self.__encryptionPswEntry=tkinter.Entry(self.__encryptionFrame,width=60)
        self.__encryptionPswEntry.grid(column=1, row=1,columnspan=3,sticky=tkinter.W)
        self.__encryptionPswCodingLabel=tkinter.Label(self.__encryptionFrame,text="编码类型",width=15)
        self.__encryptionPswCodingLabel.grid(column=0, row=2)
        self.__encryptionPswCoding=Combobox(self.__encryptionFrame,width=7)
        self.__encryptionPswCoding["values"]=["utf-8","Base64","16Hex"]
        self.__encryptionPswCoding.current(0)
        self.__encryptionPswCoding.grid(column=0, row=3)
        self.__encryptionFunctionLabel=tkinter.Label(self.__encryptionFrame,text="加密算法")
        self.__encryptionFunctionLabel.grid(column=1, row=2)
        self.__encryptionFunction=Combobox(self.__encryptionFrame,width=7)
        self.__encryptionFunction["values"]=["AES128","AES192","AES256","SM4"]
        self.__encryptionFunction.current(0)
        self.__encryptionFunction.grid(column=1, row=3)
        self.__encryptionModeLabel=tkinter.Label(self.__encryptionFrame,text="加密模式")
        self.__encryptionModeLabel.grid(column=2, row=2)
        self.__encryptionMode=Combobox(self.__encryptionFrame,width=7)
        self.__encryptionMode["values"]=["ECB","CBC","OFB","CTR","CFB1","CFB8","CFB128"]
        self.__encryptionMode.current(1)
        self.__encryptionMode.grid(column=2, row=3)
        self.__encryptionFillingLabel=tkinter.Label(self.__encryptionFrame,text="填充方式")
        self.__encryptionFillingLabel.grid(column=3, row=2)
        self.__encryptionFilling=Combobox(self.__encryptionFrame,width=7)
        self.__encryptionFilling["values"]=["PKCS7","ZERO","ANSI923","ISO10126","ISO7816_4"]
        self.__encryptionFilling.current(0)
        self.__encryptionFilling.grid(column=3, row=3)

        self.__hashFrame=tkinter.Frame(self.__Window)
        self.__hashFrame.grid(column=2, row=1)
        self.__hashFunctionLabel=tkinter.Label(self.__hashFrame,text="哈希/散列函数",font=(self.__font,12))
        self.__hashFunctionLabel.grid(column=0, row=0)
        self.__hashFunction=Combobox(self.__hashFrame,width=7)
        self.__hashFunction["values"]=["SHA224","SHA256","SHA384","SHA512","SM3"]
        self.__hashFunction.current(1)
        self.__hashFunction.grid(column=0, row=1)

        self.__MethodFrame=tkinter.Frame(self.__Window)
        self.__MethodFrame.grid(column=0, row=2,columnspan=3)
        self.__MethodR1=tkinter.Radiobutton(self.__MethodFrame,text="加密",value="-UniqueKeyEncrypt",variable=self.__MethodString,width=30)
        self.__MethodR1.grid(column=0, row=0,columnspan=2)
        self.__MethodR2=tkinter.Radiobutton(self.__MethodFrame,text="解密",value="-UniqueKeyDecrypt",variable=self.__MethodString,width=30)
        self.__MethodR2.grid(column=2, row=0,columnspan=2)
        self.__MethodR3 = tkinter.Radiobutton(self.__MethodFrame, text="哈希", value="-hash",variable=self.__MethodString,width=30)
        self.__MethodR3.grid(column=4, row=0,columnspan=2)
        self.__MethodString.set("-hash")

        self.__resultFrame=tkinter.Frame(self.__Window)
        self.__resultFrame.grid(column=0, row=3,columnspan=3)
        self.__resultTextLabel=tkinter.Label(self.__resultFrame,text="结果",font=(self.__font,12))
        self.__resultTextLabel.grid(column=0, row=0)
        self.__resultText=scrolledtext.ScrolledText(self.__resultFrame,width=100,height=10,font=("等线",10),state="disable")
        self.__resultText.grid(column=0, row=1,columnspan=20)
        self.__resultCodingLabel=tkinter.Label(self.__resultFrame,text="编码类型")
        self.__resultCodingLabel.grid(column=0, row=2,sticky=tkinter.E)
        self.__resultCoding=Combobox(self.__resultFrame,width=10)
        self.__resultCoding["values"] = ["utf-8", "Base64", "16hex(小写)","16Hex(大写)"]
        self.__resultCoding.bind("<<ComboboxSelected>>",self.extendChar)
        self.__resultCoding.current(2)
        self.__resultCoding.grid(column=1, row=2,sticky=tkinter.W)
        self.__resultSpendLabel=tkinter.Label(self.__resultFrame, text="耗时")
        self.__resultSpendLabel.grid(column=17, row=2)
        self.__resultSpend=tkinter.Label(self.__resultFrame,textvariable=self.__resultSpendString)
        self.__resultSpendString.set("0.000ms")
        self.__resultSpend.grid(column=18, row=2,columnspan=3,sticky=tkinter.W)

        self.__startButton=tkinter.Button(self.__Window,text="运行",width=70,height=2,command=self.start)
        self.__startButton.grid(column=0, row=4,columnspan=3)

        self.__Window.mainloop()
    def extendChar(self,event):
        if self.__resultCoding.get() == "Base64":
            self.__resultBase64Char1=tkinter.Label(self.__resultFrame,text="替代+")
            self.__resultBase64Char1.grid(column=2, row=2,sticky=tkinter.E)
            self.__resultBase64Char2=tkinter.Label(self.__resultFrame,text="替代/")
            self.__resultBase64Char2.grid(column=4, row=2,sticky=tkinter.E)
            self.__resultBase64Char3=tkinter.Label(self.__resultFrame,text="替代=")
            self.__resultBase64Char3.grid(column=6, row=2,sticky=tkinter.E)
            self.__resultBase64Entry1=tkinter.Entry(self.__resultFrame,width=3)
            self.__resultBase64Entry1.grid(column=3, row=2,sticky=tkinter.W)
            self.__resultBase64Entry2=tkinter.Entry(self.__resultFrame,width=3)
            self.__resultBase64Entry2.grid(column=5, row=2,sticky=tkinter.W)
            self.__resultBase64Entry3=tkinter.Entry(self.__resultFrame,width=3)
            self.__resultBase64Entry3.grid(column=7, row=2,sticky=tkinter.W)
        else:
            if self.__resultBase64Char1 is not None:
                self.__resultBase64Char1.destroy()
            if self.__resultBase64Char2 is not None:
                self.__resultBase64Char2.destroy()
            if self.__resultBase64Char3 is not None:
                self.__resultBase64Char3.destroy()
            if self.__resultBase64Entry1 is not None:
                self.__resultBase64Entry1.destroy()
            if self.__resultBase64Entry2 is not None:
                self.__resultBase64Entry2.destroy()
            if self.__resultBase64Entry3 is not None:
                self.__resultBase64Entry3.destroy()

    def start(self):
        Coding={"utf-8":"-normal","Base64":"-Base64","16hex(小写)":"-hex","16Hex(大写)":"-Hex","16Hex":"-Hex"}
        args= [self.__PINEngine, self.__MethodString.get()]
        if self.__MethodString.get()=="-hash":
            args.append("-"+self.__hashFunction.get())
            if self.__plainText.get(0.0,tkinter.END)=="":
                messagebox.showerror("错误","原文不得为空")
                return 1
            args.append(self.__plainText.get(0.0,tkinter.END))
            args.append(Coding[self.__plainCoding.get()])
            if self.__resultCoding.get() == "Base64":
                temp=Coding[self.__resultCoding.get()];
                if (self.__resultBase64Entry1.get()=="")^(self.__resultBase64Entry2.get()==""):
                    messagebox.showerror("错误","输出Base64编码自定义字符设定不全")
                    return 1
                elif self.__resultBase64Entry1.get()!="" and self.__resultBase64Entry2.get()!="":
                    temp = temp + self.__resultBase64Entry1.get()[0]
                    temp = temp + self.__resultBase64Entry2.get()[0]
                if self.__resultBase64Entry3.get().strip() != "":
                    temp = temp + self.__resultBase64Entry3.get().strip()[0]
                args.append(temp)
            else:
                args.append(Coding[self.__resultCoding.get()])
        else:
            args.append("-"+self.__encryptionFunction.get())
            args.append("-"+self.__encryptionMode.get())
            args.append("-"+self.__encryptionFilling.get())
            if self.__encryptionPswEntry.get()=="":
                messagebox.showerror("错误", "密码不得为空")
                return 1
            args.append(self.__encryptionPswEntry.get())
            args.append(Coding[self.__encryptionPswCoding.get()])
            if self.__plainText.get(0.0, tkinter.END) == "":
                messagebox.showerror("错误", "原文不得为空")
                return 1
            args.append(self.__plainText.get(0.0, tkinter.END).strip())
            args.append(Coding[self.__plainCoding.get()])
            if self.__resultCoding.get() == "Base64":
                temp = Coding[self.__resultCoding.get()]
                if (self.__resultBase64Entry1.get() == "") ^ (self.__resultBase64Entry2.get() == ""):
                    messagebox.showerror("错误", "输出Base64编码自定义字符设定不全")
                    return 1
                elif self.__resultBase64Entry1.get() != "" and self.__resultBase64Entry2.get() != "":
                    temp = temp + self.__resultBase64Entry1.get()[0]
                    temp = temp + self.__resultBase64Entry2.get()[0]
                if self.__resultBase64Entry3.get().strip() != "":
                    temp = temp + self.__resultBase64Entry3.get().strip()[0]
                args.append(temp)
            else:
                args.append(Coding[self.__resultCoding.get()])
        res=subprocess.run(args,capture_output=True, text=False)
        resBytes=res.stdout
        signString=["plaintext原文:","ciphertext密文:","hashed value散列值:"]
        resStr=[]
        resIndex=0
        timeIndex=0
        i=0
        Bytes=b""
        for c in resBytes:
            if c==10:
                try:
                    string=Bytes.decode("utf-8")
                    resStr.append(string.strip())
                    if string.strip() in signString:
                        resIndex=i+1
                    if string.strip()=="spend耗时:":
                        timeIndex=i+1
                except UnicodeDecodeError:
                    resStr.append("Error:Incorrect display encoding\n错误:不正确的展示编码")
                Bytes=b""
                i+=1
            Bytes=Bytes+c.to_bytes()
        self.__resultText.config(state=tkinter.NORMAL)
        self.__resultText.delete(0.0,tkinter.END)
        if len(resStr)<10:
            for Str in resStr:
                self.__resultText.insert(tkinter.END, Str + "\n")
            self.__resultSpendString.set("错误")
        else:
            self.__resultText.insert(tkinter.END, resStr[resIndex])
            self.__resultSpendString.set(resStr[timeIndex])
        self.__resultText.config(state=tkinter.DISABLED)
        return 0

